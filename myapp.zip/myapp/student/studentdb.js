//array of student JSON details
let students = [
    {regno:'2021ict01',name:'Ayoo',gender:'Female',course:'IT'},
    {regno:'2021ict02',name:'Chami',gender:'Female',course:'IT'},
    {regno:'2021ict03',name:'Kushi',gender:'Female',course:'IT'},
    {regno:'2021ict04',name:'Imi',gender:'Female',course:'IT'},
    {regno:'2021ict05',name:'Savi',gender:'Female',course:'IT'},
    {regno:'2021ict06',name:'Kavindu',gender:'Male',course:'IT'},
    {regno:'2021ict07',name:'Winsi',gender:'Female',course:'IT'},
    {regno:'2021ict08',name:'Nadun',gender:'Male',course:'IT'}
]

module.exports = students;